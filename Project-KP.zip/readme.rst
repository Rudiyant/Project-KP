*******************
Code Igniter HMVC include Blade Laravel
*******************
    Framework Codeigniter biasa yang dimodifikasi menjadi hirarki model view controller sehingga mempermudah proses development software yang kompleks.

    Adanya Blade Larabel untuk mempermudah dibagian pembuatan UI software, penjelasan bisa dibuka

disini : https://tataadin.blogspot.com/2019/11/web-codeigniter-dengan-hierarchical.html
disini : https://tataadin.blogspot.com/2019/11/web-codeigniter-dengan-hierarchical_29.html

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>{{$title}}</title>
  <link rel="stylesheet" href="{{base_url('assets/plugins/fontawesome-free/css/all.min.css')}}">
  <link rel="stylesheet" href="{{base_url('assets/dist/css/adminlte.min.css')}}">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  @yield('scripts-css')
  <!-- PANGGIL UNTUK INJEK CSS KE TEMPAT INI -->
</head>

<body class="hold-transition text-sm layout-top-nav">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
      <div class="container">
        <a href="index3.html" class="navbar-brand">
          <img src="{{base_url('assets/dist/img/Teladan.png')}}" alt="Teladan Logo" width="60" height="40">
        </a>
        <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse order-3" id="navbarCollapse">
          <ul class="navbar-nav">
            @include('template/menu/user/menu')
            <!-- INJEK TEMPLATE MENU KESINI -->
          </ul>
          <form class="form-inline ml-0 ml-md-3">
          </form>
        </div>
      </div>
    </nav>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container">
            <div align="center">
                <br>
              <h1 class="m-0 text-dark"> {{$title}}</h1>
              <br>
          </div>
        </div>
      </div>
      <div class="content">
        <div class="container">
          @yield('content')
          <!-- PANGGIL UNTUK INJEK CONTENT KE TEMPAT INI -->
        </div>
      </div>
    </div>

    <footer class="main-footer">
      <strong>Copyright &copy; 2014-2019 <a href="#">Sekolah Teladan Yogyakarta</a></strong>
    </footer>
  </div>
  <script src="{{base_url('assets/plugins/jquery/jquery.min.js')}}"></script>
  <script src="{{base_url('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{base_url('assets/dist/js/adminlte.min.js')}}"></script>
  @yield('scripts-js')
  
</body>

</html>